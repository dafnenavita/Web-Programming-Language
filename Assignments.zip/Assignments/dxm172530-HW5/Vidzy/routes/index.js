var express = require('express'); // requires express and returns an object 
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {  //1.request obj , 2.response obj
  res.render('index', { title: 'Express' }); // callback function , mske request , if success -> display response 
});

module.exports = router;


// get : simple read request
// send : plain text 
// redirect : redirect to a page 
// render : rende the page with title index , 2nd param is an obj - we can pass different variables and values . 
// express code now . ( similar to php) server side code 